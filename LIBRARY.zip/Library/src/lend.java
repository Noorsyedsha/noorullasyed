

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class lend
 */
@WebServlet("/lend")
public class lend extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public lend() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	
        String s1=request.getParameter("fullname");
    	System.out.println("parameters 1"+s1);
    	String s2=request.getParameter("bookid");
    	System.out.println("parameters 2"+s2);
    	String s3=request.getParameter("bookname");
    	System.out.println("parameters 3"+s3);
    	String s4=request.getParameter("author");
    	System.out.println("parameters 4"+s4);
    	String s5=request.getParameter("edition");
    	System.out.println("parameters 4"+s5);
    	ServletContext context=getServletContext();
		String s6=(String) context.getAttribute("username");
		System.out.println("parameters"+s6);
		try{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("drivers");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("connection");
			PreparedStatement ps=con.prepareStatement("insert into book2 values(?,?,?,?,?,?)");
			System.out.println("st created");
			ps.setString(1,s6);
			System.out.println("s6 done");
			ps.setString(2,s1);
			System.out.println("s1 done");
			ps.setString(3,s2);
			System.out.println("s2 done");
			ps.setString(4,s3);
			System.out.println("s3 done");
			ps.setString(5,s4);
			System.out.println("s4 done");
			ps.setString(6,s5);
			System.out.println("s5 done");
			ps.executeUpdate();
			System.out.println("done");
			context.setAttribute("full", s1);
			context.setAttribute("id", s2);
			context.setAttribute("name", s3);
			context.setAttribute("author", s4);
			context.setAttribute("edit", s5);
			RequestDispatcher rd=context.getRequestDispatcher("/reciept.jsp");
			rd.forward(request, response);
			con.close();
			
			}
			catch(Exception e){}
        
	}

}
