
import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/registerserv")
public class registerserv extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public registerserv() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String uname=request.getParameter("t3");
		
		try{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("oracle driver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("oracle driver1");
			System.out.println("oracle driver3");
			PreparedStatement os=con.prepareStatement("select  *from login");
			System.out.println("oracle driver 6");
			ResultSet rs=os.executeQuery();
			System.out.println("oracle driver 8");
			while(rs.next())
			{
				String s1=rs.getString(3);
				System.out.println("user anme"+s1);
				if(uname.equals(s1))
				{
					System.out.println("string is equal");
					RequestDispatcher rd=request.getRequestDispatcher("error.jsp");
					rd.forward(request, response);;
				}
				
			}
			RequestDispatcher rd=request.getRequestDispatcher("hai");
			rd.forward(request, response);
			}
			catch(Exception e){}
			
	}

}
