

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class hai
 */
@WebServlet("/hai")
public class hai extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public hai() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String fname=request.getParameter("t1");
		String lname=request.getParameter("t2");
		String uname=request.getParameter("t3");
		String password=request.getParameter("t4");
		String email=request.getParameter("t5");
		String number=request.getParameter("t6");
		try{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("oracle driver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("oracle driver1");
			PreparedStatement ps=con.prepareStatement("insert into login values(?,?,?,?,?,?)");
			System.out.println("oracle driver3");
		
		ps.setString(1, fname);
		ps.setString(2, lname);
		ps.setString(3, uname);
		ps.setString(4, password);
		ps.setString(5, email);
		ps.setString(6, number);
		ps.executeUpdate();
		con.close();
		RequestDispatcher rd=request.getRequestDispatcher("index.html");
		rd.forward(request, response);
		}
	

		
		catch(Exception e){}
	}

}
